package com.globallogic.library.model;

public enum Gender {
    M,
    F,
    OTHER
}
